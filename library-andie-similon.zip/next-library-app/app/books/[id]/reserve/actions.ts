"use server";

import { redirect } from "next/navigation";
import {
  getBookById,
  getReservationCountByBook,
  saveReservation,
} from "@/app/books/database";

export async function reserveBook(bookId: string, formData: FormData) {
  console.log("reserveBook called");
  console.log(formData);

  // data uit formulier halen
  let firstName = (formData.get("firstName") as any).trim();
  let lastName = (formData.get("lastName") as any).trim();
  let email = (formData.get("email") as any).trim();
  email = email.toLowerCase();

  console.log("email = " + email);

  // valideren
  if (firstName == "" || lastName == "" || email == "") {
    throw new Error("All fields are required.");
  }
  if (email.indexOf("@") > 0 == false) {
    throw new Error("Please provide a valid email address.");
  }

  // boek ophalen
  const book = await getBookById(bookId);
  if (book == null) {
    throw new Error("Book not found.");
  }

  // hoeveel zijn er al gereserveerd?
  const count = await getReservationCountByBook(bookId);
  const book2 = await getBookById(bookId);
  if (count > book2!.availableCopies) {
    throw new Error(`Sorry, "${book.title}" is no longer available.`);
  }

  // opslaan
  await saveReservation({
    bookId: bookId,
    firstName: firstName,
    lastName: lastName,
    email: email,
  });

  // await saveReservation({ bookId, firstName, lastName, email })

  console.log("saved!");

  redirect("/books/" + bookId + "/reserve/" + "done");
}
