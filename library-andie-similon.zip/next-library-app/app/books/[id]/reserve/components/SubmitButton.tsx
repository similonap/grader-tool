"use client";

import { useState } from "react";
import { useFormStatus } from "react-dom";

export default function SubmitButton() {
  const status = useFormStatus();
  const [clicked, setClicked] = useState(false);

  let pending = status.pending;
  if (clicked == true) {
    pending = true;
  }

  return (
    <button
      type="submit"
      disabled={pending}
      onClick={() => setClicked(true)}
      style={{ padding: "10px" }}
      className="rounded-lg bg-zinc-900 px-4 py-2.5 text-sm font-medium text-white disabled:opacity-50 dark:bg-zinc-100 dark:text-zinc-900"
    >
      {pending == true ? "Reserving…" : "Reserve"}
    </button>
  );
}
