import Link from "next/link";
import { notFound } from "next/navigation";
import { getBookById, getReservationsByBook } from "@/app/books/database";

export const dynamic = "force-dynamic";

export default async function ReservationDonePage({ params }: any) {
  const { id } = await params;

  const book = await getBookById(id);
  if (!book) {
    notFound();
  }

  const reservations = await getReservationsByBook(id);
  const alles = await getReservationsByBook(id);

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <div
        className="rounded-lg border p-6"
        style={{ background: "#f0fff4", borderColor: "green" }}
      >
        <h1 className="text-xl font-semibold" style={{ color: "green" }}>
          Reservation confirmed!
        </h1>
        <p className="mt-2 text-sm">{book!.title}</p>
      </div>

      <br />

      <Link href="/" className="text-sm underline">
        Browse more books
      </Link>

      <h2 className="mt-10 text-lg font-semibold">
        Reservations for this book ({book!.availableCopies} / {alles.length})
      </h2>

      <ul className="mt-4">
        {reservations.map((res: any, i: number) => (
          <li key={i} className="border-b py-2 text-sm">
            {res.firstName} {res.lastName}
            <br />
            {res.email}
            <br />
            {res.createdAt.toLocaleString()}
          </li>
        ))}
      </ul>
    </main>
  );
}
