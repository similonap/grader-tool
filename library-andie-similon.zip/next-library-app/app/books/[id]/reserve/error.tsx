"use client";

import { useEffect } from "react";

interface ErrorPageProps {
  error: Error;
  reset: () => void;
}

export default function ErrorPage(props: ErrorPageProps) {
  var error = props.error;

  useEffect(() => {
    console.error("[Server Action error]", error);
    console.log(error.message);
  });

  return (
    <main className="mx-auto max-w-xl px-6 py-16">
      <div
        className="rounded-lg border p-6"
        style={{ borderColor: "red", background: "#fff5f5" }}
      >
        <h1 className="text-xl font-semibold" style={{ color: "red" }}>
          Reservation failed
        </h1>
        <p className="mt-2 text-sm">{error.message}</p>

        <div className="mt-6">
          <button
            onClick={() => {
              props.reset();
            }}
            className="rounded-lg bg-zinc-900 px-4 py-2 text-sm text-white"
          >
            Try again
          </button>
          &nbsp;&nbsp;
          <a href="/" className="text-sm underline">
            Back to catalogue
          </a>
        </div>
      </div>
    </main>
  );
}
