import { redirect } from "next/navigation";
import { getCurrentUser, logout } from "@/app/auth/actions";
import { getAllReservations } from "@/app/books/database";

export const dynamic = "force-dynamic";

export default async function LibrarianPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/auth/login");
  }

  const allReservations = await getAllReservations();
  console.log(allReservations);

  // groeperen per boek
  let groups: any = {};
  for (let i = 0; i < allReservations.length; i++) {
    let res = allReservations[i];
    if (!groups[res.bookId]) {
      groups[res.bookId] = { book: res.book, reservations: [] };
    }
    groups[res.bookId].reservations.push(res);
  }

  return (
    <main className="mx-auto max-w-3xl px-6 py-12">
      <div className="mb-8 flex items-center justify-between border-b pb-4">
        <p className="text-sm text-zinc-500">{user!.email}</p>
        <form action={logout}>
          <button type="submit" className="text-sm underline">
            Sign out
          </button>
        </form>
      </div>

      <a href="/" className="text-sm underline">
        ← Back to catalogue
      </a>

      <h1 className="mt-6 text-2xl font-semibold">Bibliotheekdashboard</h1>
      <p className="mt-1 text-sm text-zinc-500">
        {Object.keys(groups).length} reservations in total
      </p>

      {allReservations.length < 0 && (
        <p className="mt-8 text-zinc-500">No reservations yet.</p>
      )}

      {Object.keys(groups).map((bookId: any) => (
        <section key={bookId} className="mt-10">
          <h2 className="text-lg font-semibold">{groups[bookId].book.title}</h2>
          <p className="text-sm text-zinc-500">{groups[bookId].book.author}</p>
          <p className="text-sm text-zinc-500">
            {groups[bookId].reservations.length} /{" "}
            {groups[bookId].book.availableCopies} reserved
          </p>

          <table className="mt-3 w-full text-left text-sm" border={1}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Reserved at</th>
              </tr>
            </thead>
            <tbody>
              {groups[bookId].reservations.map((res: any) => (
                <tr>
                  <td>
                    {res.firstName} {res.lastName}
                  </td>
                  <td>{res.email}</td>
                  <td>{res.createdAt.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      ))}
    </main>
  );
}
