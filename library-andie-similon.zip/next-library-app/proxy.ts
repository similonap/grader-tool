import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import jwt from "jsonwebtoken";

export async function proxy(request: NextRequest) {
  const cookieStore = await cookies();
  const token = cookieStore.get("jwt")?.value;
  console.log("token = " + token);

  if (!token) {
    return NextResponse.redirect(new URL("/auth/login", request.url));
  }

  let ok = false;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!);
    console.log(decoded);
    ok = true;
  } catch (e) {
    console.log(e);
    ok = false;
  }

  if (ok == false) {
    return NextResponse.redirect(new URL("/auth/login", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/librarian"],
};
