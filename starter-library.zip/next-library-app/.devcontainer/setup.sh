#!/bin/bash
set -e

echo "→ npm packages installeren..."
npm install

echo "→ .env.local aanmaken..."
cat > /workspace/.env.local << 'EOF'
MONGODB_URI=mongodb://admin:secret@mongo:27017/?authSource=admin
JWT_SECRET=exam-jwt-secret-2026
EOF

echo "✓ Klaar. Start de app met: npm run dev"
