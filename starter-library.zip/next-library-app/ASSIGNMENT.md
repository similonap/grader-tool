# Examen Opdracht: Bibliotheek App

## Inleiding

Je maakt een **Next.js bibliotheek applicatie** af. Het grootste deel van de app is al voor je gebouwd — jouw taak is om de onderdelen te implementeren en verder aan te vullen.

De app laat leden door de boekencatalogus bladeren en een boek reserveren. Een bibliotheekdashboard (alleen toegankelijk na inloggen) toont alle reserveringen gegroepeerd per boek.

Werk de opdrachten opeenvolgend af — elke opdracht bouwt voort op de vorige. Indien je gaandeweg ergens vastloopt, probeer je de vervolgopdrachten wel verder af te werken. Je wordt beoordeeld op de code en de werking, niet op wat er in de browser te zien is. Vul je niets in, kunnen er geen punten toegekend worden.

**Puntentotaal:** 20 punten <br>
**Tijd:** 3 uur

---

## Wat is er al voorzien

| Bestand | Status | Beschrijving |
|---------|--------|-------------|
| `app/page.tsx` | ✅ Volledig | Startpagina met de boekencatalogus |
| `app/books/[id]/page.tsx` | ✅ Volledig | Detailpagina van een boek (dynamische route) |
| `app/auth/login/page.tsx` | ✅ Volledig | Inlogformulier met inline foutmeldingen |
| `app/auth/register/page.tsx` | ✅ Volledig | Registratieformulier met inline foutmeldingen |
| `app/auth/actions.ts` | ✅ Volledig | Login, register, logout, getCurrentUser |
| `app/auth/database.ts` | ✅ Volledig | Hulpfuncties voor de gebruikerscollectie |
| `app/books/database.ts` | ✅ Volledig | Hulpfuncties voor de boeken- en reserveringsdatabase |
| `app/books/[id]/reserve/page.tsx` | ⚠️ Gedeeltelijk | HTML van het formulier voorzien; koppeling met de action ontbreekt |
| `app/layout.tsx` | ✅ Volledig | Root layout |

Elke pagina (route) bevat een `.png` bestand met een voorbeeldafbeelding van hoe de pagina er kan uitzien.


---

## Aan de slag

De app draait in een **devContainer** — een vooraf geconfigureerde ontwikkelomgeving in Docker. Je hebt geen Node.js of MongoDB lokaal nodig; alles zit ingebakken in de container.

### Vereisten

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) (geïnstalleerd en opgestart)
- [Visual Studio Code](https://code.visualstudio.com/)
- VS Code-extensie: **Dev Containers** (`ms-vscode-remote.remote-containers`)

### Opstarten

1. Open de projectmap in VS Code.
2. VS Code detecteert automatisch de devContainer-configuratie en toont rechtsonder een melding. Klik op **"Reopen in Container"**.  
   Verschijnt de melding niet, open dan het Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`) en kies **"Dev Containers: Reopen in Container"**.
3. Docker downloadt de images en start de containers op. Dit kan de eerste keer enkele minuten duren.
4. Eenmaal opgestart installeert het setup-script automatisch de npm-packages en configureert het `.env.local`. Je hoeft hier niets voor te doen.
5. Open een terminal in VS Code en start de app:
   ```bash
   npm run dev
   ```
6. Open [http://localhost:3000](http://localhost:3000) in je browser.

> De MongoDB-database en de seed-data (boeken) worden automatisch aangemaakt bij de eerste aanroep. Je hoeft geen database of omgevingsvariabelen zelf in te stellen.

> Troubleshooting: soms lukt het niet om bestanden te schrijven in `/workspaces/.next/`. Probeer deze folder dan even te verwijderen met `rm -r /workspaces/.next`.

---

### Opdracht 1 — Server Action (`app/books/[id]/reserve/actions.ts`)

Implementeer de inhoud van `reserveBook(bookId, formData)`.

De functie heeft al `"use server"` en de correcte signatuur. Vul het volgende in:

1. **Haal de data op uit het formulier:**
   - Haal `firstName`, `lastName` en `email` op uit `formData`.
   - Haal eventuele spaties rondom de opgehaalde waarden weg met behulp van `.trim()`.
   - Zet het e-mailadres om naar kleine letters.

2. **Valideer** de invoer:
   - Alle drie de velden mogen niet leeg zijn → throw `new Error("All fields are required.")`
   - Het e-mailadres moet een `@` bevatten → throw `new Error("Please provide a valid email address.")`

3. **Laad het boek** met `getBookById(bookId)`.
   Geeft dit `null` terug → throw `new Error("Book not found.")`

4. **Controleer de beschikbaarheid**: haal het aantal reserveringen op en vergelijk met `book.availableCopies`.
   Als alle exemplaren gereserveerd zijn → <code>throw new Error(\`Sorry, "${book.title}" is no longer available.\`)</code>

5. **Opslaan**: sla de reservering op met de `saveReservation({ bookId, firstName, lastName, email })` helper function.

6. **Redirect**: nadat je de reservering hebt toegevoegd aan de database zorg je ervoor dat er automatisch wordt genavigeerd naar de bevestigingspagina `/books/[id]/reserve/done`.

   ⚠️ `redirect()` gooit intern een exception — roep het **niet** aan binnen een `try/catch`.

> **Foutafhandelingspatroon**: we gooien errors in plaats van ze terug te geven, omdat dit formulier een `error.tsx`-boundary gebruikt. Elke `throw new Error()` wordt dus opgevangen door het `error.tsx`-bestand.

---

### Opdracht 2 — SubmitButton (`app/books/[id]/reserve/components/SubmitButton.tsx`)

Maak een component die een submit-button returned. Zorg ervoor dat de button even disabled wordt nadat je op de knop hebt geklikt.
- Render een `<button type="submit">` die:
  - `disabled` is wanneer `pending === true`
  - `"Reserving…"` toont wanneer pending
  - `"Reserve"` toont wanneer niet pending

---

### Opdracht 3 — Koppel het reserveringsformulier (`app/books/[id]/reserve/page.tsx`)

**A) Koppel de Server Action aan het formulier**

De Server Action `reserveBook` verwacht `(bookId, formData)`. De `action`-prop van een formulier levert alleen `formData` automatisch aan. Gebruik `.bind()` om `bookId` vooraf in te vullen:

```tsx
const action = reserveBook.bind(null, id)
<form action={action}>
```

**B) Voeg de SubmitButton toe**

Importeer `SubmitButton` uit `"./components/SubmitButton"` en render het op de plek van de `{/* TODO */}`-comment.

---

### Opdracht 4 — Error boundary (`app/books/[id]/reserve/error.tsx`)

Implementeer het error boundary Component.

Vereisten:
- Accepteer props `error: Error` en `reset: () => void`.
- Gebruik `useEffect` om `error` naar de console te loggen.
- Render een foutkaart met:
  - Een heading: `"Reservation failed"`
  - Het foutbericht uit `error.message`
  - Een **"Try again"**-knop die `reset()` aanroept
  - Een link terug naar `"/"` met het label `"Back to catalogue"`

---

### Opdracht 5 — Bevestigingspagina (`app/books/[id]/reserve/done/page.tsx`)

Implementeer de bevestigingspagina na reservering.

Dit is een **Server Component** — gebruik geen `useEffect`, en geen `fetch()`. Gebruik rechtstreeks je database helper functions.

Vereisten:
1. Haal de `id` parameter op uit de URL.
2. Haal het boek op met `getBookById(id)` → roep `notFound()` aan als het niet bestaat.
3. Haal reserveringen op met `getReservationsByBook(id)`.
4. Render:
   - Een succesbanner: `"Reservation confirmed!"` en de boektitel
   - Een `"Browse more books"`-link naar `"/"`
   - Het totale aantal reserveringen versus het aantal exemplaren: bv. `"Reservations for this book (2 / 3)"`
   - Een lijst van alle reserveringen met naam, e-mail en `createdAt`

> ⚠️ De waarde van een Reservation `_id` is ofwel `ObjectId | undefined`. De `key`-prop van React verwacht een `string | number`, en `ObjectId` (een MongoDB class-instantie) voldoet daar niet aan — evenmin als `undefined`. De oplossing is `.toString()` aanroepen: `<li key={res._id?.toString()} ...>`.

---

### Opdracht 6 — Bibliotheekdashboard (`app/librarian/page.tsx`)

Implementeer het beveiligde bibliotheekdashboard.

Dit is een **Server Component**. De route is al beveiligd door `proxy.ts`, maar verifieer de sessie altijd opnieuw binnen het component.

Vereisten:
1. Roep `getCurrentUser()` aan. Geeft dit `null` terug, navigeer dan terug naar `"/auth/login"`.
2. Haal alle reserveringen op met `getAllReservations()`.
3. Groepeer ze per `bookId` met `reduce` (zie de comment in het bestand).
4. Render:
   - Een **header** met het e-mailadres van de ingelogde gebruiker en een uitlogformulier:
     ```tsx
     <form action={logout}><button type="submit">Sign out</button></form>
     ```
   - Een link om terug te navigeren naar de catalogus
   - Een paginatitel `"Bibliotheekdashboard"` met het totale aantal reserveringen.
   - Voor elke boekgroep: de boektitel, de auteur, `"X / availableCopies reserved"`, en een tabel met kolommen `Name | Email | Reserved at`.
   - Een terugvalbericht als er nog geen reserveringen zijn.

---

### Opdracht 7 — Authenticatiebewaker (`proxy.ts`)

Implementeer de proxy-functie om het bibliotheekdashboard te beveiligen.

Vereisten:
1. Lees de `"jwt"`-cookie uit met `await cookies()` uit `"next/headers"`.
2. Als de cookie **ontbreekt** → `NextResponse.redirect(new URL("/auth/login", request.url))`
3. Als de cookie aanwezig is, verifieer dan het token:
   ```ts
   jwt.verify(token, process.env.JWT_SECRET!)
   ```
   Gebruik een `try/catch` — `jwt.verify` gooit een fout bij verlopen of ongeldige tokens.
4. Geldig → `NextResponse.next()`
5. Ongeldig/verlopen → doorsturen naar `"/auth/login"`
6. Zorg ervoor dat de proxy alleen wordt toegepast op de routes `"/librarian"` en `"/librarian/:path*"`.

---

## Route-overzicht

```
/                              → Startpagina: boekencatalogus (publiek)
/auth/login                    → Inlogformulier
/auth/register                 → Registratieformulier
/books/[id]                    → Boekdetail + beschikbare exemplaren
/books/[id]/reserve            → Reserveringsformulier         ← Opdracht 1–4
/books/[id]/reserve/done       → Bevestiging + reserveringenlijst ← Opdracht 5
/librarian                     → Bibliotheekdashboard (beveiligd) ← Opdracht 6–7
```
