/**
 * app/auth/actions.ts — Authentication Server Actions
 *
 * Three responsibilities:
 *   login    — verify credentials → sign JWT → set cookie → redirect
 *   register — create user        → sign JWT → set cookie → redirect
 *   logout   — delete cookie      → redirect to login
 *
 * getCurrentUser reads the JWT from the cookie and returns the decoded
 * payload. Called from Server Components.
 */
"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { findUserByEmail, createUser } from "./database";

// ── Types ──────────────────────────────────────────────────────────

// Shape of the state object returned to useActionState on the client.
export interface AuthState {
  error?: string;
}

export interface SessionPayload {
  email: string;
}

// ── Cookie helpers ─────────────────────────────────────────────────

const COOKIE_NAME = "jwt";

const COOKIE_OPTIONS = {
  httpOnly: true,  // Not readable by browser JS — protects against XSS
  sameSite: "lax" as const,
  secure: process.env.NODE_ENV === "production",
  maxAge: 60 * 60, // 1 hour, matching the JWT expiration
  path: "/",
};

function signToken(email: string): string {
  // jwt.sign creates a signed token containing the email.
  // The secret is loaded from .env.local — never hardcode it.
  return jwt.sign({ email }, process.env.JWT_SECRET!, { expiresIn: "1h" });
}

// ── Actions ────────────────────────────────────────────────────────

/**
 * login — validate credentials, sign a JWT, store it in a cookie.
 * Signature matches useActionState: (prevState, formData) => state.
 */
export async function login(
  _prevState: AuthState | null,
  formData: FormData
): Promise<AuthState> {
  const email = (formData.get("email") as string)?.trim().toLowerCase();
  const password = formData.get("password") as string;

  if (!email || !password) {
    return { error: "Email and password are required." };
  }

  const user = await findUserByEmail(email);
  if (!user) {
    // Return a generic message — don't reveal whether the email exists.
    return { error: "Invalid email or password." };
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    return { error: "Invalid email or password." };
  }

  const token = signToken(user.email);
  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, COOKIE_OPTIONS);

  // redirect() must be called outside try/catch — it throws internally.
  redirect("/librarian");
}

/**
 * register — validate, hash password, persist user, auto-login.
 */
export async function register(
  _prevState: AuthState | null,
  formData: FormData
): Promise<AuthState> {
  const email = (formData.get("email") as string)?.trim().toLowerCase();
  const password = formData.get("password") as string;

  if (!email || !password) {
    return { error: "Email and password are required." };
  }
  if (password.length < 6) {
    return { error: "Password must be at least 6 characters." };
  }

  const existing = await findUserByEmail(email);
  if (existing) {
    return { error: "An account with this email already exists." };
  }

  // Hash the password before storing — never save plain text.
  // Cost factor 12 is a good balance between security and speed.
  const passwordHash = await bcrypt.hash(password, 12);
  await createUser(email, passwordHash);

  const token = signToken(email);
  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, COOKIE_OPTIONS);

  redirect("/librarian");
}

/**
 * logout — delete the session cookie and return to the login page.
 * Called via <form action={logout}> so no arguments needed.
 */
export async function logout() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
  redirect("/auth/login");
}

/**
 * getCurrentUser — decode the current session.
 * Returns null when not logged in; safe to call from any Server Component.
 */
export async function getCurrentUser(): Promise<SessionPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;

  try {
    return jwt.verify(token, process.env.JWT_SECRET!) as SessionPayload;
  } catch {
    return null;
  }
}
