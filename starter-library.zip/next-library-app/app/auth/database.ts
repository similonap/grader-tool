/**
 * app/auth/database.ts — User collection helpers
 *
 * Mirrors the pattern in app/books/database.ts but for the `users`
 * collection. Passwords are NEVER stored in plain text — only the
 * bcrypt hash is persisted here.
 */

import { Collection, MongoClient } from "mongodb";

export interface User {
  _id?: string;
  email: string;
  passwordHash: string;
  createdAt: Date;
}

const uri = process.env.MONGODB_URI;

if (!uri) {
  throw new Error("MONGODB_URI environment variable is not set.");
}

const client = new MongoClient(uri);

const usersCollection: Collection<User> = client
  .db("forms_demo")
  .collection<User>("users");

export async function findUserByEmail(email: string): Promise<User | null> {
  return usersCollection.findOne({ email });
}

export async function createUser(
  email: string,
  passwordHash: string,
): Promise<void> {
  await usersCollection.insertOne({
    email,
    passwordHash,
    createdAt: new Date(),
  });
}
