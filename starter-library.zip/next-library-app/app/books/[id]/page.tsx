export const dynamic = "force-dynamic";

import Link from "next/link";
import { notFound } from "next/navigation";
import { getBookById, getReservationCountByBook } from "@/app/books/database";

export default async function BookDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const book = await getBookById(id);
  if (!book) notFound();

  const reservationCount = await getReservationCountByBook(id);
  const copiesLeft = book.availableCopies - reservationCount;
  const isUnavailable = copiesLeft <= 0;

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <Link
        href="/"
        className="mb-8 inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200"
      >
        ← All books
      </Link>

      <article>
        <div className="mb-6">
          <h1 className="text-3xl font-semibold tracking-tight text-zinc-900 dark:text-zinc-50">
            {book.title}
          </h1>

          <div className="mt-4 flex flex-wrap gap-2">
            <span className="rounded-full bg-zinc-100 px-3 py-1 text-xs font-medium text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300">
              ✍️ {book.author}
            </span>
            <span className="rounded-full bg-zinc-100 px-3 py-1 text-xs font-medium text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300">
              📚 {book.genre}
            </span>
            <span
              className={`rounded-full px-3 py-1 text-xs font-medium ${
                isUnavailable
                  ? "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400"
                  : "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
              }`}
            >
              {isUnavailable
                ? "Not available"
                : `${copiesLeft} cop${copiesLeft === 1 ? "y" : "ies"} available`}
            </span>
          </div>
        </div>

        <p className="text-base leading-relaxed text-zinc-700 dark:text-zinc-300">
          {book.description}
        </p>

        <div className="mt-8">
          {isUnavailable ? (
            <p className="text-sm font-medium text-red-600 dark:text-red-400">
              All copies are currently reserved.
            </p>
          ) : (
            <Link
              href={`/books/${id}/reserve`}
              className="inline-flex items-center gap-2 rounded-lg bg-zinc-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-zinc-300"
            >
              Reserve this book →
            </Link>
          )}
        </div>
      </article>
    </main>
  );
}
