/**
 * app/books/[id]/reserve/actions.ts — Server Action voor boekereserveringen
 *
 * "use server" bovenaan markeert elke geëxporteerde functie als Server Action.
 *
 * EXTRA ARGUMENTEN DOORGEVEN MET .bind():
 *   De `action`-prop van een formulier levert normaal alleen FormData aan.
 *   Om ook de bookId uit de URL mee te geven, gebruikt de pagina .bind():
 *
 *     const action = reserveBook.bind(null, bookId)
 *     <form action={action}>
 *
 *   Dit vult `bookId` vooraf in als eerste argument. Wanneer het formulier
 *   wordt ingediend, roept Next.js het volgende aan:
 *
 *     reserveBook(bookId, formData)
 *
 * JOUW TAAK — implementeer de inhoud van reserveBook():
 *
 *   1. **Haal de data op uit het formulier:**
 *      - Haal `firstName`, `lastName` en `email` op uit `formData`.
 *      - Haal eventuele spaties rondom de opgehaalde waarden weg met behulp van `.trim()`.
 *      - Zet het e-mailadres om naar kleine letters.
 *
 *   2. Valideer de invoer:
 *      Gooi een Error als er iets fout is; error.tsx vangt dit op.
 *
 *   3. Laad het boek met getBookById(bookId). Gooi een fout als het niet bestaat.
 *
 *   4. Controleer de beschikbaarheid: vergelijk getReservationCountByBook(bookId)
 *      met book.availableCopies. Gooi een fout als alle exemplaren gereserveerd zijn.
 *
 *   5. Roep saveReservation({ bookId, firstName, lastName, email }) aan.
 *
 *   6. Stuur door naar de bevestigingspagina: "/books/[id]/reserve/done"
 *
 *      BELANGRIJK: redirect() werkt door intern een exception te gooien —
 *      roep het NIET aan binnen een try/catch-block, anders wordt het onderdrukt.
 */
"use server";

import { redirect } from "next/navigation";
import {
  getBookById,
  getReservationCountByBook,
  saveReservation,
} from "@/app/books/database";

/**
 * reserveBook — valideert formulierinvoer en slaat een boekreservering op.
 *
 * @param bookId   - vooraf ingevuld via .bind() in het page-component
 * @param formData - automatisch door Next.js geïnjecteerd vanuit het HTML-formulier
 */
export async function reserveBook(bookId: string, formData: FormData) {
  // TODO: implementeer deze Server Action
  // 1. Haal firstName, lastName, email op uit het formulier (verwijder witruimte)
  // 2. Valideer: alle velden verplicht; email moet "@" bevatten
  //    → throw new Error("...") bij falen (error.tsx vangt dit op)
  // 3. Laad het boek — gooi een fout als getBookById null teruggeeft
  // 4. Controleer beschikbaarheid — gooi een fout als het aantal reserveringen >= book.availableCopies
  // 5. Sla de reservering op met saveReservation(...)
  // 6. redirect naar "/books/[id]/reserve/done"
}
