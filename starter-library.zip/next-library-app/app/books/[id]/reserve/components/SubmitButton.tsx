/**
 * SubmitButton.tsx — Component dat de formulierindieningstatus weergeeft
 *
 * JOUW TAAK — implementeer deze Component:
 *
 *   Render een <button type="submit"> die:
 *        - disabled is wanneer pending === true
 *        - "Reserving…" toont wanneer pending === true
 *        - "Reserve" toont wanneer pending === false
 */

// TODO: implementeer de SubmitButton Component
