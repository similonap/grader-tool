/**
 * app/books/[id]/reserve/done/page.tsx — Bevestiging na reservering
 *
 * Dit is een Server Component: geen "use client", geen useState, geen fetch().
 * Je kunt database-functies rechtstreeks awaiten op het hoogste niveau.
 *
 * JOUW TAAK — implementeer deze pagina:
 *
 *   1. Haal de id parameter op uit de URL.
 *
 *   2. Haal het boek op met getBookById(id).
 *      Bestaat het boek niet, roep dan notFound() aan uit "next/navigation".
 *
 *   3. Haal alle reserveringen voor dit boek op met getReservationsByBook(id).
 *
 *   4. Render de pagina met:
 *        a) Een succesbanner: "Reservation confirmed!" en de boektitel
 *        b) Een "Browse more books"-link terug naar "/"
 *        c) Een lijst van alle reserveringen met firstName, lastName, email
 *           en createdAt per lid
 *        d) Een heading met het aantal reserveringen versus het totale aantal exemplaren
 *           bv. "Reservations for this book (2 / 3)"
 *
 * Benodigde imports:
 *   import Link from "next/link"
 *   import { notFound } from "next/navigation"
 *   import { getBookById, getReservationsByBook } from "@/app/books/database"
 */

export const dynamic = "force-dynamic";

// TODO: implementeer de bevestigingspagina
export default async function ReservationDonePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  // TODO:
  // 1. id parameter ophalen uit URL
  // 2. boek informatie ophalen met getBookById(id)
  //    - als boek niet bestaat, notFound() aanroepen
  // 3. reserveringen ophalen met getReservationsByBook(id)
  // 4. return JSX met succesbanner + reserveringenlijst

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <p className="text-zinc-500">TODO: implementeer deze pagina.</p>
    </main>
  );
}
