/**
 * error.tsx — Error boundary voor de reserveringsformulierroute
 *
 * Next.js rendert dit component automatisch wanneer er een onafgehandelde fout
 * wordt gegooid ergens binnen dit route-segment — ook vanuit Server Actions.
 *
 * Component moet twee props accepteren:
 *        error  — het Error-object dat werd gegooid
 *        reset  — een callback die de route opnieuw rendert, zodat de gebruiker
 *                 het opnieuw kan proberen
 *
 * JOUW TAAK — implementeer deze error boundary:
 *
 *   1. Definieer de ErrorPageProps-interface:
 *        error: Error
 *        reset: () => void
 *
 *   2. Voeg een useEffect toe die de fout naar de console logt:
 *        console.error("[Server Action error]", error)
 *
 *   3. Render een foutkaart met:
 *        - Een heading: "Reservation failed"
 *        - Het foutbericht: {error.message}
 *        - Een "Try again"-knop die reset() aanroept
 *        - Een link terug naar "/" (terug naar de catalogus)
 *
 */

// TODO: implementeer het error boundary-component
