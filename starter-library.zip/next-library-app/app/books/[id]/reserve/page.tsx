/**
 * app/books/[id]/reserve/page.tsx — Reserveringsformulier (Server Component)
 *
 * Deze pagina is grotendeels al volledig. Jouw taak bevindt zich in het <form>-element.
 *
 * JOUW TAAK:
 *
 *   A) Koppel het formulier aan de Server Action met .bind():
 *
 *      De Server Action reserveBook verwacht twee argumenten:
 *        reserveBook(bookId: string, formData: FormData)
 *
 *      De `action`-prop van een formulier levert alleen FormData automatisch aan.
 *      Gebruik .bind() om de bookId vooraf in te vullen:
 *
 *        const action = reserveBook.bind(null, id)
 *        <form action={action}>
 *
 *      Door .bind(null, id) aan te roepen, krijg je een nieuwe functie terug
 *      waarbij `id` al het eerste argument is. Wanneer de browser het formulier
 *      indient, roept Next.js het volgende aan:
 *        reserveBook(id, formData)
 *
 *   B) Voeg een <SubmitButton /> toe binnen het <form>.
 *
 * De formulier-HTML (inputs, labels, resetknop) is al voorzien.
 */

import { notFound } from "next/navigation";
import Link from "next/link";
import { getBookById } from "@/app/books/database";
import { getCurrentUser } from "@/app/auth/actions";
import { reserveBook } from "./actions";
// TODO: importeer SubmitButton uit "./components/SubmitButton"

export default async function ReservePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const book = await getBookById(id);
  if (!book) notFound();

  const user = await getCurrentUser();

  // TODO: declareer `action` met reserveBook.bind(null, id)

  return (
    <main className="mx-auto max-w-xl px-6 py-12">
      <Link
        href={`/books/${id}`}
        className="mb-8 inline-flex items-center gap-1 text-sm text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200"
      >
        ← Back to book
      </Link>

      <div className="mb-8">
        <h1 className="text-2xl font-semibold tracking-tight text-zinc-900 dark:text-zinc-50">
          Reserve {book.title}
        </h1>
        <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
          {book.author}
        </p>
        <p className="mt-2 text-sm text-zinc-500 dark:text-zinc-400">
          Fill in your details to reserve this book.
        </p>
      </div>

      {/*
        TODO: voeg action={action} toe aan het <form>-element hieronder.
        De `action`-variabele die je hebt gedeclareerd met .bind() komt hier.
      */}
      <form className="space-y-5">
        <div className="grid gap-5 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="firstName"
              className="text-sm font-medium text-zinc-700 dark:text-zinc-300"
            >
              First name
            </label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              required
              className="rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-50 dark:focus:ring-zinc-300"
              placeholder="Ada"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="lastName"
              className="text-sm font-medium text-zinc-700 dark:text-zinc-300"
            >
              Last name
            </label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              required
              className="rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-50 dark:focus:ring-zinc-300"
              placeholder="Lovelace"
            />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <label
            htmlFor="email"
            className="text-sm font-medium text-zinc-700 dark:text-zinc-300"
          >
            Email address
          </label>
          <input
            type="email"
            id="email"
            name="email"
            required
            defaultValue={user?.email ?? ""}
            className="rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-50 dark:focus:ring-zinc-300"
            placeholder="ada@example.com"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-1">
          <button
            type="reset"
            className="rounded-lg px-4 py-2.5 text-sm font-medium text-zinc-600 transition-colors hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"
          >
            Reset
          </button>
          {/* TODO: render <SubmitButton /> hier */}
        </div>
      </form>
    </main>
  );
}
