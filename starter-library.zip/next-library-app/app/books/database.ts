/**
 * app/books/database.ts — Books and reservations database helpers
 *
 * Two MongoDB collections live here:
 *   books        — the library catalogue (seeded on first use)
 *   reservations — one document per member reservation
 *
 * WHAT IS PROVIDED:
 *   getBooks()                         — returns all books, sorted by title
 *   getBookById()                      — returns one book by ObjectId string
 *   saveReservation()                  — insert a reservation into MongoDB
 *   getReservationsByBook()            — fetch all reservations for one book
 *   getReservationCountByBook()        — count reservations for capacity check
 *   getAllReservations()               — fetch all reservations joined with books
 */

import { Collection, MongoClient, ObjectId } from "mongodb";

// ── Types ──────────────────────────────────────────────────────────────────

export interface Book {
  _id?: ObjectId;
  title: string;
  author: string;
  description: string;
  genre: string;
  availableCopies: number;
}

export interface Reservation {
  _id?: ObjectId;
  bookId: string;
  firstName: string;
  lastName: string;
  email: string;
  createdAt: Date;
}

/** Reservation joined with its parent Book — used on the librarian dashboard. */
export type ReservationWithBook = Reservation & { book?: Book };

// ── Connection ─────────────────────────────────────────────────────────────

const uri = process.env.MONGODB_URI;
if (!uri) throw new Error("MONGODB_URI environment variable is not set.");

const client = new MongoClient(uri);
const db = client.db("library");

const booksCollection: Collection<Book> = db.collection("books");
const reservationsCollection: Collection<Reservation> =
  db.collection("reservations");

// ── Seed data ──────────────────────────────────────────────────────────────

const SEED_BOOKS: Omit<Book, "_id">[] = [
  {
    title: "Clean Code",
    author: "Robert C. Martin",
    description:
      "A handbook of agile software craftsmanship. Martin presents best practices for writing clean, readable and maintainable code. Essential reading for any developer who cares about their craft.",
    genre: "Technologie",
    availableCopies: 3,
  },
  {
    title: "The Design of Everyday Things",
    author: "Don Norman",
    description:
      "A powerful primer on how and why some products satisfy customers while others only frustrate them. Norman shows that good design means making things understandable and usable for the people who use them.",
    genre: "Design",
    availableCopies: 2,
  },
  {
    title: "Atomic Habits",
    author: "James Clear",
    description:
      "No matter your goals, Atomic Habits offers a proven framework for improving every day. Clear reveals practical strategies that will teach you how to form good habits, break bad ones, and master the tiny behaviours that lead to remarkable results.",
    genre: "Zelfontwikkeling",
    availableCopies: 5,
  },
];

async function seedIfEmpty(): Promise<void> {
  const count = await booksCollection.countDocuments();
  if (count === 0) {
    await booksCollection.insertMany(SEED_BOOKS);
  }
}

// ── Books ──────────────────────────────────────────────────────────────────

/** Returns all books sorted by title ascending. Seeds the collection on first call. */
export async function getBooks(): Promise<Book[]> {
  await seedIfEmpty();
  return booksCollection.find().sort({ title: 1 }).toArray();
}

/** Returns a single book by its ObjectId string, or null if not found. */
export async function getBookById(id: string): Promise<Book | null> {
  await seedIfEmpty();
  try {
    return booksCollection.findOne({ _id: new ObjectId(id) });
  } catch {
    return null;
  }
}

// ── Reservations ───────────────────────────────────────────────────────────

/**
 * saveReservation — persists a new reservation to MongoDB.
 *
 * @param data  The reservation data WITHOUT _id and createdAt.
 *              Set createdAt to new Date() before inserting.
 */
export async function saveReservation(
  data: Omit<Reservation, "_id" | "createdAt">
): Promise<void> {
  await reservationsCollection.insertOne({ ...data, createdAt: new Date() });
}

/**
 * getReservationsByBook — returns all reservations for a given book.
 *
 * @param bookId  The book's ObjectId as a string (from the URL).
 * @returns       Array of Reservation documents, sorted by createdAt ascending.
 */
export async function getReservationsByBook(
  bookId: string
): Promise<Reservation[]> {
  return await reservationsCollection
    .find({ bookId })
    .sort({ createdAt: 1 })
    .toArray();
}

/**
 * getReservationCountByBook — returns the number of reservations for a book.
 *
 * Used in the Server Action to enforce the book's availableCopies limit.
 *
 * @param bookId  The book's ObjectId as a string.
 * @returns       The number of reservations (0 if none).
 */
export async function getReservationCountByBook(
  bookId: string
): Promise<number> {
  return await reservationsCollection.countDocuments({ bookId });
}

/**
 * getAllReservations — returns ALL reservations joined with their book.
 *
 * Used on the librarian dashboard to show a complete overview.
 *
 * @returns  Array of ReservationWithBook, sorted by createdAt descending.
 */
export async function getAllReservations(): Promise<ReservationWithBook[]> {
  const reservations = await reservationsCollection
    .find()
    .sort({ createdAt: -1 })
    .toArray();
  const books = await getBooks();
  const bookMap = new Map(books.map((b) => [b._id!.toString(), b]));
  return reservations.map((r) => ({ ...r, book: bookMap.get(r.bookId) }));
}
