/**
 * app/librarian/page.tsx — Bibliotheekdashboard (Server Component)
 *
 * Deze route is beveiligd door proxy.ts: niet-geauthenticeerde verzoeken worden
 * doorgestuurd naar /auth/login voordat dit component ooit wordt uitgevoerd.
 * Verifieer de sessie toch altijd opnieuw binnen het component als tweede
 * beveiligingslaag.
 *
 * JOUW TAAK — implementeer deze pagina:
 *
 *   1. Verifieer authenticatie met getCurrentUser().
 *      Geeft het null terug, stuur dan door naar "/auth/login".
 *
 *   2. Haal alle reserveringen op met getAllReservations().
 *      Dit geeft ReservationWithBook[] terug — elke reservering bevat
 *      een optioneel .book-veld met het bijbehorende Book-document.
 *
 *   3. Groepeer de reserveringen per bookId zodat je één sectie per boek
 *      kunt renderen:
 *
 *      const groups = allReservations.reduce<Record<string, { book, reservations[] }>>(
 *        (acc, res) => {
 *          if (!acc[res.bookId]) acc[res.bookId] = { book: res.book, reservations: [] };
 *          acc[res.bookId].reservations.push(res);
 *          return acc;
 *        }, {}
 *      );
 *
 *   4. Render het dashboard met:
 *        a) Een headerbalk met het e-mailadres van de ingelogde gebruiker en een uitlogknop.
 *           Gebruik <form action={logout}><button>Sign out</button></form>
 *
 *        b) Een titel: "Bibliotheekdashboard" en het totale aantal reserveringen.
 *
 *        c) Voor elke boekgroep:
 *           - De boektitel, de auteur en "X / availableCopies reserved"
 *           - Een tabel met kolommen: Name | Email | Reserved at
 *
 *        d) Een terugvalbericht als er nog geen reserveringen zijn.
 *
 * Benodigde imports:
 *   import { redirect } from "next/navigation"
 *   import Link from "next/link"
 *   import { getCurrentUser, logout } from "@/app/auth/actions"
 *   import { getAllReservations } from "@/app/books/database"
 *   import type { Book, Reservation } from "@/app/books/database"
 */

export const dynamic = "force-dynamic";

// TODO: implementeer het bibliotheekdashboard
export default async function LibrarianPage() {
  // TODO:
  // 1. const user = await getCurrentUser()  →  if (!user) redirect("/auth/login")
  // 2. const allReservations = await getAllReservations()
  // 3. Groepeer reserveringen per bookId
  // 4. Render header (met uitloggen), dashboardtitel en gegroepeerde tabellen

  return (
    <main className="mx-auto max-w-3xl px-6 py-12">
      <p className="text-zinc-500">TODO: implementeer deze pagina.</p>
    </main>
  );
}
