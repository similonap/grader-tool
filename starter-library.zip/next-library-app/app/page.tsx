export const dynamic = "force-dynamic";

import Link from "next/link";
import { getBooks } from "./books/database";

export default async function HomePage() {
  const books = await getBooks();

  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <div className="mb-10">
        <h1 className="text-3xl font-semibold tracking-tight text-zinc-900 dark:text-zinc-50">
          Boekencatalogus
        </h1>
        <p className="mt-2 text-sm text-zinc-500 dark:text-zinc-400">
          Blader door onze collectie en reserveer een boek.
        </p>
      </div>

      {books.length === 0 ? (
        <p className="text-sm text-zinc-500">Geen boeken beschikbaar.</p>
      ) : (
        <ul className="space-y-4">
          {books.map((book) => (
            <li
              key={book._id!.toString()}
              className="rounded-xl border border-zinc-200 bg-white p-6 dark:border-zinc-800 dark:bg-zinc-900"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <h2 className="truncate text-lg font-semibold text-zinc-900 dark:text-zinc-50">
                    {book.title}
                  </h2>
                  <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
                    {book.author} · {book.genre}
                  </p>
                  <p className="mt-3 line-clamp-2 text-sm text-zinc-700 dark:text-zinc-300">
                    {book.description}
                  </p>
                </div>
                <span className="shrink-0 rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                  {book.availableCopies} ex.
                </span>
              </div>
              <div className="mt-5">
                <Link
                  href={`/books/${book._id!.toString()}`}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-zinc-900 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-zinc-300"
                >
                  Bekijk details →
                </Link>
              </div>
            </li>
          ))}
        </ul>
      )}

      <div className="mt-12 rounded-xl border border-zinc-200 bg-zinc-50 p-5 dark:border-zinc-800 dark:bg-zinc-900/50">
        <p className="text-sm text-zinc-600 dark:text-zinc-400">
          <span className="font-medium text-zinc-900 dark:text-zinc-200">
            Bibliotheekmedewerker?
          </span>{" "}
          <Link
            href="/librarian"
            className="underline underline-offset-4 hover:text-zinc-900 dark:hover:text-zinc-200"
          >
            Ga naar het bibliotheekdashboard →
          </Link>
        </p>
      </div>
    </main>
  );
}
