/**
 * lib/mongodb.ts — Shared MongoDB client
 *
 * Both app/books/database.ts and app/auth/database.ts import from
 * here so the connection pool is created only once, regardless of how
 * many modules need a DB handle.
 */

import { MongoClient, Db } from "mongodb";

const uri = process.env.MONGODB_URI;
if (!uri) throw new Error("MONGODB_URI is not set in .env.local");

declare global {
  // eslint-disable-next-line no-var
  var _mongoClient: MongoClient | undefined;
}

function getClient(): MongoClient {
  if (!global._mongoClient) {
    global._mongoClient = new MongoClient(uri!);
  }
  return global._mongoClient;
}

export function getDb(): Db {
  return getClient().db("forms_demo");
}
