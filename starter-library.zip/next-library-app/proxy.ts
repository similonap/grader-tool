/**
 * proxy.ts — Authenticatiebewaker
 *
 * JOUW TAAK — implementeer de proxy()-functie:
 *
 *   1. Lees de "jwt"-cookie uit het inkomende verzoek.
 *      Hint: gebruik cookies() uit "next/headers" om cookies te benaderen
 *      (het geeft een Promise terug — await het).
 *
 *   2. Als de cookie ONTBREEKT → stuur door naar "/auth/login".
 *      Hint: NextResponse.redirect(new URL("/auth/login", request.url))
 *
 *   3. Als de cookie aanwezig is → verifieer de JWT-handtekening.
 *      Hint: jwt.verify(token, process.env.JWT_SECRET!) uit "jsonwebtoken".
 *      Gebruik een try/catch: jwt.verify gooit een fout bij verlopen/ongeldige tokens.
 *
 *   4. Geldig token → laat het verzoek door: NextResponse.next()
 *      Ongeldig/verlopen token → stuur door naar "/auth/login"
 *
 * De config.matcher onderaan beperkt op welke routes deze proxy van toepassing is.
 * Alleen het bibliotheekdashboard (/librarian en subpaden) moet beveiligd zijn.
 * Publieke routes (/, /books/*, /auth/*) moeten zonder inloggen toegankelijk blijven.
 *
 * Beschikbare imports (al aanwezig in dit project):
 *   import { cookies } from "next/headers";
 *   import { NextResponse } from "next/server";
 *   import type { NextRequest } from "next/server";
 *   import jwt from "jsonwebtoken";
 */

import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import jwt from "jsonwebtoken";

export async function proxy(request: NextRequest) {
  // TODO: implementeer de authenticatiebewaker
  // Stap 1: lees de jwt-cookie
  // Stap 2: als ontbrekend → stuur door naar /auth/login
  // Stap 3: verifieer de JWT; als ongeldig/verlopen → stuur door naar /auth/login
  // Stap 4: geldig token → return NextResponse.next()
}

export const config = {
  // TODO: vul de matcher in zodat alleen /librarian (en subpaden) beveiligd is.
  matcher: [],
};
